from django.conf import settings
from django.core.validators import MaxValueValidator, MinValueValidator
from django.db import models

class Parada(models.Model):
    nombre = models.CharField(max_length=120)
    latitud = models.FloatField(validators=[MinValueValidator(-90), MaxValueValidator(90)])
    longitud = models.FloatField(validators=[MinValueValidator(-180), MaxValueValidator(180)])

    def __str__(self):
        return self.nombre

class Ruta(models.Model):
    nombre_ruta = models.CharField(max_length=120)
    descripcion = models.TextField(blank=True, null=True)
    color = models.CharField(max_length=20, blank=True)
    administrador = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, related_name='rutas')
    paradas = models.ManyToManyField(Parada, through='RutaParada', related_name='rutas')

    def __str__(self):
        return self.nombre_ruta

class RutaParada(models.Model):
    ruta = models.ForeignKey(Ruta, on_delete=models.CASCADE)
    parada = models.ForeignKey(Parada, on_delete=models.CASCADE)
    orden = models.PositiveIntegerField(default=0)

    class Meta:
        unique_together = ('ruta', 'parada')
        ordering = ['ruta', 'orden']

    def __str__(self):
        return f"{self.ruta.nombre_ruta} - {self.orden} - {self.parada.nombre}"
