from django.contrib import admin
from .models import Ruta, Parada, RutaParada

class RutaParadaInline(admin.TabularInline):
    model = RutaParada
    extra = 1

@admin.register(Ruta)
class RutaAdmin(admin.ModelAdmin):
    list_display = ('nombre_ruta', 'administrador', 'cantidad_paradas')
    search_fields = ('nombre_ruta', 'descripcion')
    list_filter = ('administrador',)
    inlines = [RutaParadaInline]

    def cantidad_paradas(self, obj):
        return obj.paradas.count()
    cantidad_paradas.short_description = 'Nº paradas'

@admin.register(Parada)
class ParadaAdmin(admin.ModelAdmin):
    list_display = ('nombre', 'latitud', 'longitud')
    search_fields = ('nombre',)
