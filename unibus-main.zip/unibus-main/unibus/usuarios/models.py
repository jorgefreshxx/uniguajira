from django.db import models
from django.contrib.auth.models import AbstractUser

class Usuario(AbstractUser):
    ROLES = (
        ('ESTUDIANTE', 'Estudiante'),
        ('ADMIN', 'Administrador'),
        ('CONDUCTOR', 'Conductor'),
    )

    nombre = models.CharField('Nombre completo', max_length=150, blank=True)
    email = models.EmailField('Correo electrónico', unique=True)
    rol = models.CharField(max_length=20, choices=ROLES, default='ESTUDIANTE')

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['username']

    def __str__(self):
        return f"{self.get_full_name() or self.email} ({self.rol})"
