from django.conf import settings
from django.core.validators import MinValueValidator, MaxValueValidator
from django.db import models

class Bus(models.Model):
    placa = models.CharField(max_length=20, unique=True)
    capacidad = models.PositiveIntegerField(default=40)
    ruta_actual = models.ForeignKey('rutas.Ruta', on_delete=models.SET_NULL, null=True, blank=True, related_name='buses')
    conductor = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name='buses')

    def __str__(self):
        return f"{self.placa} ({self.ruta_actual})"

class UbicacionBus(models.Model):
    bus = models.ForeignKey(Bus, on_delete=models.CASCADE, related_name='ubicaciones')
    latitud = models.FloatField(validators=[MinValueValidator(-90), MaxValueValidator(90)])
    longitud = models.FloatField(validators=[MinValueValidator(-180), MaxValueValidator(180)])
    fecha_hora = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-fecha_hora']

    def __str__(self):
        return f"{self.bus.placa} @ {self.fecha_hora}"
