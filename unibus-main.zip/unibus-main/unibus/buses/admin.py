from django.contrib import admin
from .models import Bus, UbicacionBus

class UbicacionInline(admin.TabularInline):
    model = UbicacionBus
    extra = 0
    readonly_fields = ('latitud', 'longitud', 'fecha_hora')
    can_delete = False

@admin.register(Bus)
class BusAdmin(admin.ModelAdmin):
    list_display = ('placa', 'ruta_actual', 'conductor', 'capacidad')
    search_fields = ('placa',)
    list_filter = ('ruta_actual',)
    inlines = [UbicacionInline]

@admin.register(UbicacionBus)
class UbicacionBusAdmin(admin.ModelAdmin):
    list_display = ('bus', 'latitud', 'longitud', 'fecha_hora')
    search_fields = ('bus__placa',)
    list_filter = ('bus',)
